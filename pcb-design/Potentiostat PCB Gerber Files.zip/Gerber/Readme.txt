PCB FR-4 thikness 1.6mm.
Final copper minimum thickness 35um.  

Color GREEN

Layer stack definition

Extension			Description

.DRL				Drill Data
.GBL				Bottom Layer
.GBO				Bottom Overlay
.GBP				Bottom Paste
.GBR				Component Mount information 
.GBS				Bottom Solder
.GM1, .GM2, etc.		Mechanical Layer 1, 2, etc.
.GP1, .GP2, etc.		Internal Plane Layer 1, 2, etc.
.GTL				Top Layer
.GTO				Top Overlay
.GTP				Top Paste
.GTS				Top Solder
.POS    			SMD mounting position
